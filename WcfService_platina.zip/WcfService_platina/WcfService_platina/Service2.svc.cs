﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data.SqlClient;

namespace WcfService_platina
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de clase "Service2" en el código, en svc y en el archivo de configuración a la vez.
    // NOTA: para iniciar el Cliente de prueba WCF para probar este servicio, seleccione Service2.svc o Service2.svc.cs en el Explorador de soluciones e inicie la depuración.
    public class Service2 : IService2
    {
        public void crear(int cla, string cat, string mat, float pre, string pro, string cli)
        {
            SqlConnection con;
            SqlCommand cmd;
            string cadena = "";
            con = new SqlConnection("Data Source=localhost;Initial Catalog=platina;Integrated Security=true");
            con.Open();
            cadena = "insert into joyeria values('" + cla + "','" + cat + "','" + mat + "','" + pre + "','" + pro + "','" + cli + "')";
            cmd = new SqlCommand(cadena, con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public string[] buscar(int cla)
        {
            SqlConnection con;
            SqlCommand cmd;
            SqlDataReader dato;
            string cadena = "";
            string[] datos = new string[6];
            con = new SqlConnection("Data Source=localhost;Initial Catalog=platina;Integrated Security=true");
            con.Open();
            cadena = "select * from joyeria where clave=" + cla;
            cmd = new SqlCommand(cadena, con);
            dato = cmd.ExecuteReader();
            if (dato.Read())
            {
                datos[0] = dato.GetInt32(0).ToString();
                datos[1] = dato.GetString(1);
                datos[2] = dato.GetString(2);
                datos[3] = dato.GetDecimal(3).ToString();
                datos[4] = dato.GetString(4);
                datos[5] = dato.GetString(5);
            }
            con.Close();
            return datos;
        }
        public bool modificar(int cla, string cat, string mat, float pre, string pro, string cli)
        {
            SqlConnection con;
            SqlCommand cmd;
            string cadena = "";
            con = new SqlConnection("Data Source=localhost;Initial Catalog=platina;Integrated Security=true");
            con.Open();
            cadena = "UPDATE joyeria SET clave = ('" + cla + "'),categoria = ('" + cat + "'), material = ('" + mat + "'), precio = ('" + pre + "'), proveedor = ('" + pro + "'), cliente = ('" + cli + "') where clave =('" + cla + "')";
            cmd = new SqlCommand(cadena, con);
            if (cmd.ExecuteNonQuery() > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
            con.Close();
        }
        public bool eliminar(int cla)
        {
            SqlConnection con;
            SqlCommand cmd;
            string cadena = "";
            con = new SqlConnection("Data Source=localhost;Initial Catalog=platina;Integrated Security=true");
            con.Open();
            cadena = "delete from joyeria where clave = " + cla;
            cmd = new SqlCommand(cadena, con);
            if (cmd.ExecuteNonQuery() > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
            con.Close();
        }
    }
}
